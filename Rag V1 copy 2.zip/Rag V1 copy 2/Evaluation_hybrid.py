import sys
import types

# -----------------------------------------------------------------------------
# SHIM: Resolve RAGAS legacy VertexAI import bug on newer LangChain / Python 3.13
# -----------------------------------------------------------------------------
dummy_vertex = types.ModuleType("langchain_community.chat_models.vertexai")
dummy_vertex.ChatVertexAI = type("ChatVertexAI", (object,), {})
sys.modules["langchain_community.chat_models.vertexai"] = dummy_vertex

try:
    import langchain_community.llms
    langchain_community.llms.VertexAI = type("VertexAI", (object,), {})
except Exception:
    pass
# -----------------------------------------------------------------------------

import json
import re
import time
from pathlib import Path
import pandas as pd
from datasets import Dataset

# LangChain & Ollama Integrations
from langchain_ollama import ChatOllama, OllamaEmbeddings

# RAGAS Framework & Execution Controls
from ragas import evaluate
from ragas.run_config import RunConfig
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper

try:
    from ragas.metrics import (
        context_precision,
        context_recall,
        faithfulness,
        answer_relevancy
    )
    ragas_metrics = [context_precision, context_recall, faithfulness, answer_relevancy]
except ImportError:
    from ragas.metrics import (
        ContextPrecision,
        ContextRecall,
        Faithfulness,
        AnswerRelevancy
    )
    ragas_metrics = [ContextPrecision(), ContextRecall(), Faithfulness(), AnswerRelevancy()]

import config
from vectorstore_hybrid import get_hybrid_rerank_retriever
from generator_hybrid import build_generator_chain, format_context_with_sources


def load_golden_set(file_path: Path) -> list:
    """Loads 50 golden questions from evaluation/questions.json."""
    if not file_path.exists():
        raise FileNotFoundError(f"Missing evaluation file: {file_path}")

    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, dict) and "questions" in data:
        items = data["questions"]
    elif isinstance(data, list):
        items = data
    else:
        raise ValueError("Invalid format: expected a list or a dict containing 'questions'.")

    print(f"Loaded {len(items)} golden set questions from {file_path.name}")
    return items


def extract_citations(text: str) -> list[str]:
    """Extracts cited PDF filenames from model output."""
    tagged = re.findall(r'\[(?:source:\s*)?([a-zA-Z0-9_\-\.]+\.pdf)\]', text, re.IGNORECASE)
    if tagged:
        return [t.strip() for t in tagged]
    return re.findall(r'[a-zA-Z0-9_\-\.]+\.pdf', text, re.IGNORECASE)


def run_hybrid_eval(golden_items, retriever, generator_chain, max_samples=None):
    """Executes hybrid retrieval, generates answers, and computes source metrics."""
    if max_samples:
        golden_items = golden_items[:max_samples]

    records = []
    total = len(golden_items)

    for idx, item in enumerate(golden_items, 1):
        question = item["question"]
        reference = item.get("reference", "")
        expected_src = item.get("source_document", "").strip()

        print(f"[{idx}/{total}] Hybrid inference: {question[:60]}...")

        # 1. Fast Hybrid Retrieval (Top 5 reranked chunks)
        retrieved_docs = retriever.invoke(question)
        contexts = [d.page_content for d in retrieved_docs]
        retrieved_sources = [d.metadata.get("source", "").strip() for d in retrieved_docs]

        # 2. Answer Generation (LLaMA 3.1)
        context_str = format_context_with_sources(retrieved_docs)
        answer = generator_chain.invoke({"context": context_str, "question": question})

        # 3. Fast Regex Source Evaluation
        citations = extract_citations(answer)
        retrieval_hit = 1.0 if any(expected_src.lower() in s.lower() for s in retrieved_sources) else 0.0
        citation_hit = 1.0 if any(expected_src.lower() in c.lower() for c in citations) or (expected_src.lower() in answer.lower()) else 0.0

        if citations:
            correct_cites = sum(1 for c in citations if expected_src.lower() in c.lower())
            source_precision = correct_cites / len(citations)
        else:
            source_precision = 0.0

        records.append({
            "question": question,
            "ground_truth": reference,
            "answer": answer,
            "contexts": contexts,
            "expected_source": expected_src,
            "retrieved_sources": retrieved_sources,
            "cited_sources": citations,
            "retrieval_source_hit": retrieval_hit,
            "citation_source_hit": citation_hit,
            "source_precision": source_precision
        })

    return records


def main():
    eval_dir = config.BASE_DIR / "Evaluation"
    eval_dir.mkdir(parents=True, exist_ok=True)
    questions_file = eval_dir / "evaluation_questions.json"

    golden_set = load_golden_set(questions_file)

    # ---------------------------------------------------------
    # SPEED OPTIMIZATION 1: top_k=5 and candidate_k=15
    # ---------------------------------------------------------
    print("\n[Speed Config] Initializing Hybrid Retriever with top_k=5, candidate_k=15...")
    hybrid_retriever = get_hybrid_rerank_retriever(top_k=5, candidate_k=15)

    print("Configuring LLaMA 3.1 generator chain...")
    generator_chain = build_generator_chain()

    # Step 1: Run generation inference on all 50 questions
    start_time = time.time()
    records = run_hybrid_eval(golden_set, hybrid_retriever, generator_chain, max_samples=None)

    raw_cache_file = eval_dir / "hybrid_raw_predictions.json"
    with open(raw_cache_file, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, ensure_ascii=False)
    print(f"\nInference completed in {(time.time() - start_time) / 60:.2f} min. Predictions cached.")

    # Step 2: Prepare dataset for RAGAS
    ragas_dataset = Dataset.from_dict({
        "question": [r["question"] for r in records],
        "answer": [r["answer"] for r in records],
        "contexts": [r["contexts"] for r in records],
        "ground_truth": [r["ground_truth"] for r in records]
    })

    # ---------------------------------------------------------
    # SPEED OPTIMIZATION 2: Fast 3B Judge & Controlled Workers
    # ---------------------------------------------------------
    print("\nRunning RAGAS evaluation with fast local Judge (llama3.2:3b)...")
    judge_llm = ChatOllama(model="llama3.2:3b", temperature=0)
    judge_emb = OllamaEmbeddings(model=config.EMBEDDING_MODEL)

    ragas_llm = LangchainLLMWrapper(judge_llm)
    ragas_emb = LangchainEmbeddingsWrapper(judge_emb)

    for m in ragas_metrics:
        if hasattr(m, "llm"):
            m.llm = ragas_llm
        if hasattr(m, "embeddings"):
            m.embeddings = ragas_emb

    # RunConfig: max_workers=2 avoids local Ollama request jamming and timeouts
    run_config = RunConfig(max_workers=2, timeout=90)

    ragas_scores = evaluate(
        dataset=ragas_dataset,
        metrics=ragas_metrics,
        llm=ragas_llm,
        embeddings=ragas_emb,
        run_config=run_config
    )

    # Step 3: Aggregate Metrics safely
    df = pd.DataFrame(records)
    ragas_df = ragas_scores.to_pandas()

    final_df = pd.concat([
        df,
        ragas_df.drop(columns=["question", "contexts", "answer", "ground_truth"], errors="ignore")
    ], axis=1)

    csv_path = eval_dir / "hybrid_model_evaluation_report.csv"
    final_df.to_csv(csv_path, index=False)

    total_time = (time.time() - start_time) / 60

    def get_metric_mean(target_name):
        for col in final_df.columns:
            if target_name.lower() in col.lower():
                return float(final_df[col].dropna().mean())
        return 0.0

    cp = get_metric_mean("context_precision")
    cr = get_metric_mean("context_recall")
    faith = get_metric_mean("faithfulness")
    ar = get_metric_mean("answer_relevancy")
    avg_retrieval_hit = get_metric_mean("retrieval_source_hit")
    avg_citation_hit = get_metric_mean("citation_source_hit")
    avg_prec = get_metric_mean("source_precision")

    # Step 4: Print Benchmark Report
    print("\n" + "=" * 55)
    print("      HYBRID (BM25 + DENSE + RERANK) REPORT      ")
    print("=" * 55)
    print(f"Questions Evaluated     : {len(records)}")
    print(f"Total Execution Time    : {total_time:.2f} minutes")
    print("-" * 55)
    print("RETRIEVAL QUALITY (Top-5):")
    print(f"  • Context Precision   : {cp:.4f}")
    print(f"  • Context Recall      : {cr:.4f}")
    print(f"  • Retrieval Source Hit: {avg_retrieval_hit:.2%}")
    print("-" * 55)
    print("GENERATION & CITATIONS:")
    print(f"  • Faithfulness        : {faith:.4f}")
    print(f"  • Answer Relevancy    : {ar:.4f}")
    print(f"  • Citation Source Hit : {avg_citation_hit:.2%}")
    print(f"  • Source Precision    : {avg_prec:.2%}")
    print("=" * 55)
    print(f"Full per-sample report saved to: {csv_path.name}")


if __name__ == "__main__":
    main()