from pathlib import Path

# Core Paths
BASE_DIR = Path("/Users/karthikkashal/Documents/Rag V1")
POLICY_DIR = BASE_DIR / "policy_Documents"
CLAIMS_DIR = BASE_DIR / "Claims_info"

# Output Paths
OUTPUT_DIR = BASE_DIR / "parsed_outputs"
CHROMA_DB_DIR = BASE_DIR / "chroma_db"

# Local Ollama Models
EMBEDDING_MODEL = "nomic-embed-text"
LLM_MODEL = "llama3.1"

# Automatically create output directories
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
CHROMA_DB_DIR.mkdir(parents=True, exist_ok=True)