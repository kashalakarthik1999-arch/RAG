import json
from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma
from langchain_ollama import OllamaEmbeddings
import config

def build_dense_retriever(chunks=None):
    print("\n--- Initializing Dense Vector Store ---")
    local_embeddings = OllamaEmbeddings(model=config.EMBEDDING_MODEL)
    
    # If the database already exists, load it from disk
    if config.CHROMA_DB_DIR.exists() and any(config.CHROMA_DB_DIR.iterdir()) and not chunks:
        print("Loading existing Chroma database...")
        vectorstore = Chroma(
            persist_directory=str(config.CHROMA_DB_DIR),
            embedding_function=local_embeddings
        )
    else:
        # Otherwise, build a new database from the chunks
        if not chunks:
            json_path = config.OUTPUT_DIR / "corpus_chunks.json"
            if not json_path.exists():
                raise FileNotFoundError("No chunks provided and corpus_chunks.json not found.")
            with open(json_path, "r", encoding="utf-8") as f:
                chunks = json.load(f)
                
        print(f"Embedding {len(chunks)} chunks into new Chroma database...")
        documents = [
            Document(page_content=c["text"], metadata=c["metadata"]) 
            for c in chunks
        ]
        
        vectorstore = Chroma.from_documents(
            documents=documents, 
            embedding=local_embeddings,
            persist_directory=str(config.CHROMA_DB_DIR)
        )
        
    # Return a retriever configured to fetch the top 10 most semantically similar chunks
    return vectorstore.as_retriever(search_kwargs={"k": 10})