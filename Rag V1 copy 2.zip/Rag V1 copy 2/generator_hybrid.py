from langchain_ollama import ChatOllama
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough

import config


HYBRID_PROMPT_TEMPLATE = """You are an expert Insurance Policy & Claims Assistant.
Answer the user's question using ONLY the provided context below.

DOCUMENT HIERARCHY & CITATION RULES:
1. CITATIONS: Provide inline citations for every factual statement using the format.
2. CUSTOMER DATA ISOLATION: When asked about a specific policyholder (by name or policy number), NEVER mix details, schedules, or endorsements belonging to other individuals (e.g., P05, P07, P10).
3. MASTER CONTRACT WORDING: You MAY use general contract documents (e.g., motor_policy_wording_2.pdf) to explain general terms and standard definitions.
4. REFUSAL PATH: If the answer cannot be determined from the provided context, state: "I cannot answer this question based on the provided documents."

Context:
{context}

Question: {question}

Answer:"""


def format_context_with_sources(docs) -> str:
    """Formats retrieved document chunks with explicit source markers."""
    formatted = []
    for doc in docs:
        src = doc.metadata.get("source", "Unknown")
        formatted.append(f"--- Document Source: {src} ---\n{doc.page_content}")
    return "\n\n".join(formatted)


def build_generator_chain():
    """
    Returns the core generator runnable taking: {'context': str, 'question': str}.
    Used by evaluation scripts where retrieved documents need to be inspected before generation.
    """
    llm = ChatOllama(model=config.LLM_MODEL, temperature=0)
    prompt = PromptTemplate.from_template(HYBRID_PROMPT_TEMPLATE)
    return prompt | llm | StrOutputParser()


def build_rag_chain(retriever):
    """
    Returns an end-to-end RAG chain taking a raw query string.
    Retrieves top chunks, formats context, and returns the generated answer.
    """
    generator_chain = build_generator_chain()

    return (
        {
            "context": retriever | format_context_with_sources,
            "question": RunnablePassthrough(),
        }
        | generator_chain
    )