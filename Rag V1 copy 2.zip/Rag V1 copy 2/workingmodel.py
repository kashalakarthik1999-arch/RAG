import config
from ingest_chunk import process_all_documents
from vectorstore import build_dense_retriever
from generator import build_rag_chain

def main():
    print("=== Aviva Policy & Claims RAG Assistant ===")
    
    # 1. Check if we need to ingest data (if the JSON file doesn't exist)
    json_path = config.OUTPUT_DIR / "corpus_chunks.json"
    chunks = None
    
    if not json_path.exists():
        print("No parsed chunks found. Starting parsing and chunking phase...")
        chunks = process_all_documents()
    else:
        print(f"Found existing parsed chunks at {json_path.name}")
        
    # 2. Build or Load the Dense Retriever
    retriever = build_dense_retriever(chunks)
    
    # 3. Setup the Generation Chain
    rag_chain = build_rag_chain(retriever)
    
    # 4. Interactive Query Loop
    print("\nPipeline ready! Type 'exit' to quit.")
    print("-" * 50)
    
    while True:
        query = input("\nEnter your query: ")
        if query.lower() in ['exit', 'quit']:
            print("Exiting...")
            break
            
        if not query.strip():
            continue
            
        print("\nSearching and Generating...")
        response = rag_chain.invoke(query)
        
        print("\n--- Response ---")
        print(response)
        print("-" * 50)

if __name__ == "__main__":
    main()