import config
from ingest_chunk import process_all_documents
from vectorstore_hybrid import get_hybrid_rerank_retriever
from generator_hybrid import build_rag_chain


def main():
    print("=" * 65)
    print("  Aviva Distinct Motor Assistant: HYBRID (BM25 + Dense + Rerank)  ")
    print("=" * 65)

    # 1. Verify parsed chunks exist on disk
    json_path = config.OUTPUT_DIR / "corpus_chunks.json"
    if not json_path.exists():
        print("No parsed chunks found. Executing document ingestion...")
        process_all_documents()
    else:
        print(f"Found existing parsed corpus: {json_path.name}")

    # 2. Build Hybrid Retriever (Candidate pool: 20 -> Reranked filter: top 10)
    retriever = get_hybrid_rerank_retriever(top_k=10, candidate_k=20)

    # 3. Setup RAG Chain
    rag_chain = build_rag_chain(retriever)

    print("\nHybrid RAG Assistant is ready. Enter 'exit' to quit.\n" + "-" * 65)

    # 4. Interactive Loop
    while True:
        query = input("\nEnter your query: ")
        if query.lower() in ["exit", "quit"]:
            break
        if not query.strip():
            continue

        print("\nRetrieving (BM25 + nomic-embed-text -> BGE Reranker) and Generating...")
        response = rag_chain.invoke(query)

        print("\n--- Response ---")
        print(response)
        print("-" * 65)


if __name__ == "__main__":
    main()