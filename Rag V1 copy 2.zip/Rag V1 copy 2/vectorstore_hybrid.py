import json
from pathlib import Path

from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma
from langchain_community.retrievers import BM25Retriever
from langchain_ollama import OllamaEmbeddings
from langchain_community.cross_encoders import HuggingFaceCrossEncoder

# Safe fallback imports for LangChain classic/standard packages
try:
    from langchain.retrievers import EnsembleRetriever, ContextualCompressionRetriever
    from langchain.retrievers.document_compressors import CrossEncoderReranker
except (ImportError, ModuleNotFoundError):
    from langchain_classic.retrievers import EnsembleRetriever, ContextualCompressionRetriever
    from langchain_classic.retrievers.document_compressors import CrossEncoderReranker

import config


def load_corpus_documents() -> list[Document]:
    """Loads parsed chunks from corpus_chunks.json."""
    json_path = config.OUTPUT_DIR / "corpus_chunks.json"
    if not json_path.exists():
        raise FileNotFoundError(
            f"Corpus chunks not found at: {json_path}. Run ingest_chunk.py first."
        )

    with open(json_path, "r", encoding="utf-8") as f:
        raw_chunks = json.load(f)

    return [
        Document(page_content=item["text"], metadata=item["metadata"])
        for item in raw_chunks
    ]


def get_dense_retriever(documents: list[Document], k: int = 20):
    """Connects to the persistent Chroma index with nomic-embed-text."""
    embeddings = OllamaEmbeddings(model=config.EMBEDDING_MODEL)

    if config.CHROMA_DB_DIR.exists() and any(config.CHROMA_DB_DIR.iterdir()):
        print("[Hybrid] Loading existing Chroma dense index from disk...")
        vectorstore = Chroma(
            persist_directory=str(config.CHROMA_DB_DIR),
            embedding_function=embeddings
        )
    else:
        print(f"[Hybrid] Indexing {len(documents)} chunks in Chroma...")
        vectorstore = Chroma.from_documents(
            documents=documents,
            embedding=embeddings,
            persist_directory=str(config.CHROMA_DB_DIR)
        )

    return vectorstore.as_retriever(search_kwargs={"k": k})


def get_bm25_retriever(documents: list[Document], k: int = 20):
    """Constructs in-memory BM25 index for exact token and policy ID matching."""
    print("[Hybrid] Building BM25 sparse keyword index...")
    bm25 = BM25Retriever.from_documents(documents)
    bm25.k = k
    return bm25


def get_hybrid_rerank_retriever(top_k: int = 10, candidate_k: int = 20):
    """
    Two-stage Hybrid pipeline:
    1. EnsembleRetriever (BM25 + nomic-embed-text) fetches candidate_k candidates via RRF.
    2. CrossEncoderReranker (BAAI/bge-reranker-base) re-ranks and filters to top_k chunks.
    """
    documents = load_corpus_documents()

    # Stage 1: Base Candidate Retrieval (20 candidates each)
    dense_retriever = get_dense_retriever(documents=documents, k=candidate_k)
    bm25_retriever = get_bm25_retriever(documents=documents, k=candidate_k)

    print("[Hybrid] Combining retrievers with Reciprocal Rank Fusion (50/50 weight)...")
    ensemble = EnsembleRetriever(
        retrievers=[bm25_retriever, dense_retriever],
        weights=[0.5, 0.5]
    )

    # Stage 2: Cross-Encoder Joint Reranking
    print("[Hybrid] Loading BAAI/bge-reranker-base cross-encoder...")
    cross_encoder = HuggingFaceCrossEncoder(model_name="BAAI/bge-reranker-base")
    compressor = CrossEncoderReranker(model=cross_encoder, top_n=top_k)

    print(f"[Hybrid] Pipeline ready. Fusing top {candidate_k} candidates -> filtering to top {top_k}.")
    return ContextualCompressionRetriever(
        base_compressor=compressor,
        base_retriever=ensemble
    )