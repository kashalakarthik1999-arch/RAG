from langchain_ollama import ChatOllama
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
import config

def format_docs(docs):
    formatted = []
    for doc in docs:
        src = doc.metadata.get('source', 'Unknown')
        formatted.append(f"--- Document Source: {src} ---\n{doc.page_content}")
    return "\n\n".join(formatted)

def build_rag_chain(retriever):
    print("\n--- Setting up LLM and Generation Chain ---")
    llm = ChatOllama(model=config.LLM_MODEL, temperature=0)
    
    template = """You are an expert Insurance Policy & Claims Assistant.
Answer the user's question using ONLY the provided context below. 

CITATION RULES:
1. Do not use general knowledge to fill information gaps.
2. Do not invent policy language, coverage, exclusions, limits,
   definitions, conditions, or facts.
3. Clearly distinguish coverage, exclusions, conditions, duties,
   definitions, and limits.
4. Cite each important conclusion using labels such as [Source 1].
5. Do not cite a source unless it supports the statement.
6. If the context is insufficient, state that the supplied document
   context does not contain enough information.
7. Do not make a final coverage determination.
8. State that final coverage depends on the complete policy,
   endorsements, facts of loss, applicable law, and claims review.
9. Keep the answer concise and professionally worded.
Context:
{context}

Question: {question}

Answer:"""
    
    prompt = PromptTemplate.from_template(template)
    
    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    
    return rag_chain