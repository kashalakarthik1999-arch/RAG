import sys
import types

# -----------------------------------------------------------------------------
# SHIM: Resolve RAGAS legacy VertexAI import bug on newer LangChain / Python 3.13
# -----------------------------------------------------------------------------
dummy_vertex = types.ModuleType("langchain_community.chat_models.vertexai")
dummy_vertex.ChatVertexAI = type("ChatVertexAI", (object,), {})
sys.modules["langchain_community.chat_models.vertexai"] = dummy_vertex

try:
    import langchain_community.llms
    langchain_community.llms.VertexAI = type("VertexAI", (object,), {})
except Exception:
    pass
# -----------------------------------------------------------------------------

import json
import re
import time
from pathlib import Path
import pandas as pd
from datasets import Dataset

# LangChain & Ollama Integrations
from langchain_ollama import ChatOllama, OllamaEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser

# RAGAS Evaluation Framework
from ragas import evaluate
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper

# Cross-version compatibility for RAGAS metrics
try:
    from ragas.metrics import (
        context_precision,
        context_recall,
        faithfulness,
        answer_relevancy
    )
    ragas_metrics = [context_precision, context_recall, faithfulness, answer_relevancy]
except ImportError:
    from ragas.metrics import (
        ContextPrecision,
        ContextRecall,
        Faithfulness,
        AnswerRelevancy
    )
    ragas_metrics = [ContextPrecision(), ContextRecall(), Faithfulness(), AnswerRelevancy()]

import config


def load_golden_set(file_path: Path) -> list:
    """Loads 50 golden questions from evaluation/questions.json."""
    if not file_path.exists():
        raise FileNotFoundError(f"Missing evaluation file: {file_path}")

    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, dict) and "questions" in data:
        items = data["questions"]
    elif isinstance(data, list):
        items = data
    else:
        raise ValueError("Invalid format: expected a list or a dict containing 'questions'.")

    print(f"Loaded {len(items)} golden set questions from {file_path.name}")
    return items


def get_dense_retriever(k: int = 10):
    """Initializes pure dense retriever using nomic-embed-text and Chroma."""
    embeddings = OllamaEmbeddings(model=config.EMBEDDING_MODEL)

    if not config.CHROMA_DB_DIR.exists() or not any(config.CHROMA_DB_DIR.iterdir()):
        raise FileNotFoundError(
            f"Chroma index not found in {config.CHROMA_DB_DIR}. Run ingest and indexing first."
        )

    vectorstore = Chroma(
        persist_directory=str(config.CHROMA_DB_DIR),
        embedding_function=embeddings
    )
    return vectorstore.as_retriever(search_kwargs={"k": k})


def extract_citations(text: str) -> list[str]:
    """Extracts cited PDF filenames from model output."""
    tagged = re.findall(r'\[(?:source:\s*)?([a-zA-Z0-9_\-\.]+\.pdf)\]', text, re.IGNORECASE)
    if tagged:
        return [t.strip() for t in tagged]

    # Fallback pattern for inline PDF name mentions
    return re.findall(r'[a-zA-Z0-9_\-\.]+\.pdf', text, re.IGNORECASE)


def format_context(docs) -> str:
    """Formats chunks with explicit source headers for prompt isolation."""
    formatted = []
    for doc in docs:
        src = doc.metadata.get("source", "Unknown")
        formatted.append(f"--- Document Source: {src} ---\n{doc.page_content}")
    return "\n\n".join(formatted)


def run_dense_eval(golden_items, retriever, rag_chain, max_samples=2):
    """Executes dense retrieval, generates answers, and calculates source metrics."""
    if max_samples:
        golden_items = golden_items[:max_samples]

    records = []
    total = len(golden_items)

    for idx, item in enumerate(golden_items, 1):
        question = item["question"]
        reference = item.get("reference", "")
        expected_src = item.get("source_document", "").strip()

        print(f"[{idx}/{total}] Processing: {question[:65]}...")

        # 1. Pure Dense Retrieval
        retrieved_docs = retriever.invoke(question)
        contexts = [d.page_content for d in retrieved_docs]
        retrieved_sources = [d.metadata.get("source", "").strip() for d in retrieved_docs]

        # 2. Response Generation
        context_str = format_context(retrieved_docs)
        answer = rag_chain.invoke({"context": context_str, "question": question})

        # 3. Custom Source Hit & Precision Calculation
        citations = extract_citations(answer)

        # Retrieval Source Hit: Did dense search find the document?
        retrieval_hit = 1.0 if any(expected_src.lower() in s.lower() for s in retrieved_sources) else 0.0

        # Citation Source Hit: Did the LLM cite the document in the answer?
        citation_hit = 1.0 if any(expected_src.lower() in c.lower() for c in citations) or (expected_src.lower() in answer.lower()) else 0.0

        # Source Precision: Ratio of accurate citations to total citations made
        if citations:
            correct_cites = sum(1 for c in citations if expected_src.lower() in c.lower())
            source_precision = correct_cites / len(citations)
        else:
            source_precision = 0.0

        records.append({
            "question": question,
            "ground_truth": reference,
            "answer": answer,
            "contexts": contexts,
            "expected_source": expected_src,
            "retrieved_sources": retrieved_sources,
            "cited_sources": citations,
            "retrieval_source_hit": retrieval_hit,
            "citation_source_hit": citation_hit,
            "source_precision": source_precision
        })

    return records


def main():
    eval_dir = config.BASE_DIR / "Evaluation"
    eval_dir.mkdir(parents=True, exist_ok=True)
    questions_file = eval_dir / "evaluation_questions.json"

    # 1. Load Ground Truth Set
    golden_set = load_golden_set(questions_file)

    # 2. Build Dense Retriever & Generation Chain
    print("Loading pure Dense Retriever (Chroma + nomic-embed-text)...")
    dense_retriever = get_dense_retriever(k=10)

    print("Configuring LLaMA 3.1 generator chain...")
    llm = ChatOllama(model=config.LLM_MODEL, temperature=0)
    prompt_template = PromptTemplate.from_template(
        """You are an expert Insurance Policy & Claims Assistant.
Answer the user's question using ONLY the provided context below.

CITATION RULES:
1. Do not use general knowledge to fill information gaps.
2. Do not invent policy language, coverage, exclusions, limits,
   definitions, conditions, or facts.
3. Clearly distinguish coverage, exclusions, conditions, duties,
   definitions, and limits.
4. Cite each important conclusion using labels such as [Source 1].
5. Do not cite a source unless it supports the statement.
6. If the context is insufficient, state that the supplied document
   context does not contain enough information.
7. Do not make a final coverage determination.
8. State that final coverage depends on the complete policy,
   endorsements, facts of loss, applicable law, and claims review.
9. Keep the answer concise and professionally worded.
Context:
{context}

Question: {question}

Answer:"""
    )
    rag_chain = prompt_template | llm | StrOutputParser()

    # 3. Run Pipeline Inference
    # Set max_samples=None to run all 50 questions
    start_time = time.time()
    records = run_dense_eval(golden_set, dense_retriever, rag_chain, max_samples=None)

    # Cache raw model outputs before scoring
    raw_cache_file = eval_dir / "dense_raw_predictions.json"
    with open(raw_cache_file, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, ensure_ascii=False)
    print(f"\nInference completed. Predictions saved to: {raw_cache_file.name}")

    # 4. Prepare Dataset for RAGAS
    ragas_dataset = Dataset.from_dict({
        "question": [r["question"] for r in records],
        "answer": [r["answer"] for r in records],
        "contexts": [r["contexts"] for r in records],
        "ground_truth": [r["ground_truth"] for r in records]
    })

    # 5. Run RAGAS LLM-as-a-Judge Evaluation
    print("\nRunning RAGAS evaluation with local LLM Judge...")
    judge_llm = ChatOllama(model=config.LLM_MODEL, temperature=0)
    judge_emb = OllamaEmbeddings(model=config.EMBEDDING_MODEL)

    ragas_llm = LangchainLLMWrapper(judge_llm)
    ragas_emb = LangchainEmbeddingsWrapper(judge_emb)

    for m in ragas_metrics:
        if hasattr(m, "llm"):
            m.llm = ragas_llm
        if hasattr(m, "embeddings"):
            m.embeddings = ragas_emb

    ragas_scores = evaluate(
        dataset=ragas_dataset,
        metrics=ragas_metrics,
        llm=ragas_llm,
        embeddings=ragas_emb
    )

    # 6. Aggregate Custom & RAGAS Metrics via to_pandas() (prevents AttributeError)
    df = pd.DataFrame(records)
    ragas_df = ragas_scores.to_pandas()

    final_df = pd.concat([
        df,
        ragas_df.drop(columns=["question", "contexts", "answer", "ground_truth"], errors="ignore")
    ], axis=1)

    csv_path = eval_dir / "dense_model_evaluation_report.csv"
    final_df.to_csv(csv_path, index=False)

    total_time = (time.time() - start_time) / 60

    def get_metric_mean(target_name):
        for col in final_df.columns:
            if target_name.lower() in col.lower():
                return float(final_df[col].dropna().mean())
        return 0.0

    cp = get_metric_mean("context_precision")
    cr = get_metric_mean("context_recall")
    faith = get_metric_mean("faithfulness")
    ar = get_metric_mean("answer_relevancy")
    avg_retrieval_hit = get_metric_mean("retrieval_source_hit")
    avg_citation_hit = get_metric_mean("citation_source_hit")
    avg_prec = get_metric_mean("source_precision")

    # 7. Print Final Benchmark Report
    print("\n" + "=" * 55)
    print("      DENSE-ONLY MODEL EVALUATION REPORT       ")
    print("=" * 55)
    print(f"Questions Evaluated     : {len(records)}")
    print(f"Evaluation Duration     : {total_time:.2f} minutes")
    print("-" * 55)
    print("RETRIEVAL QUALITY:")
    print(f"  • Context Precision   : {cp:.4f}")
    print(f"  • Context Recall      : {cr:.4f}")
    print(f"  • Retrieval Source Hit: {avg_retrieval_hit:.2%}")
    print("-" * 55)
    print("GENERATION & CITATIONS:")
    print(f"  • Faithfulness        : {faith:.4f}")
    print(f"  • Answer Relevancy    : {ar:.4f}")
    print(f"  • Citation Source Hit : {avg_citation_hit:.2%}")
    print(f"  • Source Precision    : {avg_prec:.2%}")
    print("=" * 55)
    print(f"Detailed output stored at:\n -> {csv_path}")


if __name__ == "__main__":
    main()