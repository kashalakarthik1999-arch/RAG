import json
from pathlib import Path

from docling.document_converter import DocumentConverter, PdfFormatOption
from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling.datamodel.accelerator_options import AcceleratorOptions
from docling.chunking import HybridChunker

import config

def parse_and_chunk(folder_path: Path, doc_type: str):
    if not folder_path.exists():
        print(f"[!] Directory not found: {folder_path}")
        return []

    print(f"Initializing Docling converter for {doc_type}...")
    
    # --- FIXED: Safe Pipeline Configuration ---
    # Apply threads via AcceleratorOptions and disable OCR directly on PdfPipelineOptions
    pipeline_options = PdfPipelineOptions(
        do_ocr=False,  # Disables OCR for native PDFs (saves massive memory)
        accelerator_options=AcceleratorOptions(
            num_threads=1  # Forces single-threaded execution (fixes loky segfault)
        )
    )
    
    converter = DocumentConverter(
        allowed_formats=[InputFormat.PDF],
        format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)
        }
    )
    
    # Initialize chunker
    chunker = HybridChunker(max_tokens=512, merge_peers=True)

    records = []
    pdf_files = sorted(list(folder_path.glob("*.pdf")))
    
    for pdf_path in pdf_files:
        print(f" -> Parsing and chunking: {pdf_path.name}")
        try:
            docling_doc = converter.convert(pdf_path).document
            
            for chunk_idx, chunk in enumerate(chunker.chunk(docling_doc)):
                enriched_text = chunker.contextualize(chunk)
                
                records.append({
                    "text": enriched_text,
                    "metadata": {
                        "source": pdf_path.name,
                        "document_type": doc_type,
                        "chunk_id": f"{pdf_path.stem}_{chunk_idx}"
                    }
                })
        except Exception as e:
            print(f"    [Error] Failed to process {pdf_path.name}: {e}")

    return records

def process_all_documents():
    print("\n--- Starting Ingestion and Chunking ---")
    all_chunks = []
    
    policy_chunks = parse_and_chunk(config.POLICY_DIR, "customer_contract")
    all_chunks.extend(policy_chunks)
    
    claims_chunks = parse_and_chunk(config.CLAIMS_DIR, "internal_procedure")
    all_chunks.extend(claims_chunks)
    
    output_file = config.OUTPUT_DIR / "corpus_chunks.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(all_chunks, f, indent=2, ensure_ascii=False)
        
    print(f"\nSuccessfully extracted {len(all_chunks)} total chunks.")
    print(f"Saved for verification to: {output_file}")
    
    return all_chunks

if __name__ == "__main__":
    process_all_documents()